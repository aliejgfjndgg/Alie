# HyperLauncher: Architecture Overview

Kotlin + Jetpack Compose launcher inspired by HyperOS: spring-driven motion, minimal icons, glass surfaces.

## 1. Layers

```
app/src/main/
├── AndroidManifest.xml          HOME intent filter, package visibility
├── res/values/themes.xml        Transparent window showing the wallpaper
└── java/com/hyper/launcher/
    ├── MainActivity.kt          Home activity, edge-to-edge, hosts Compose
    ├── data/LauncherData.kt     Models, AppRepository (PackageManager + icon cache), LauncherViewModel
    └── ui/HomeScreen.kt         Pager workspace, draggable grid cells, dock, page indicator
    (next)  ui/ControlCenter.kt  Blur panel, toggles, sliders, media card
    (next)  ui/AppDrawer.kt      LazyVerticalGrid, search, category tabs
    (next)  ui/Gestures.kt       Swipe up/down + pinch, shared drag state
```

Data flow is one-directional:
`PackageManager -> AppRepository -> LauncherViewModel (StateFlow) -> Compose UI -> events back to ViewModel`

## 2. Key decisions

| Concern | Decision | Why |
|---|---|---|
| Grid | Fixed cells sized from `BoxWithConstraints`; each cell positioned by a per-cell `Animatable<Offset>` | O(items) layout, trivial drag math, spans possible later |
| Paging | `HorizontalPager`, `beyondViewportPageCount = 1`, scrolling disabled while dragging | Lazy pages, no gesture conflict |
| Motion | Springs for everything touch-driven (move, press, page dots) | Interruptible, preserves velocity, feels "fluid" |
| Per-frame values | Read inside `offset {}` / `graphicsLayer {}` lambdas only | Animation runs in layout/draw, zero recomposition per frame |
| Icons | `LruCache<String, ImageBitmap>` (96 entries, 144px), decoded on `Dispatchers.IO` | Low memory, no scroll jank |
| State | Immutable data classes, `StateFlow`, stable keys per cell | Cheap diffing, cells skip recomposition |
| Persistence | Not wired yet; replace the in-memory `MutableStateFlow` with Room | Layout survives restarts |

## 3. Glassmorphism caveat

`Modifier.blur()` in Compose blurs a composable's own content, not the wallpaper behind it. For a real frosted Control Center:

- **Android 12+ (API 31):** host the panel in its own window (Dialog/Activity/overlay) and call `window.setBackgroundBlurRadius(radiusPx)` (or `blurBehindRadius` on the window attributes). The system composites it on the GPU, which is cheap.
- **API < 31 fallback:** translucent gradient + 1dp light border. The dock in this first pass already uses it.

## 4. Build setup

`app/build.gradle.kts`: minSdk 26, targetSdk 35 (raise to the newest stable).

```kotlin
dependencies {
    implementation(platform("androidx.compose:compose-bom:<latest-stable>"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:<latest>")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:<latest>")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:<latest>")
    implementation("androidx.core:core-ktx:<latest>")
}
```

`res/values/themes.xml`:

```xml
<resources>
    <style name="Theme.HyperLauncher" parent="android:Theme.Material.NoActionBar">
        <item name="android:windowShowWallpaper">true</item>
        <item name="android:windowBackground">@android:color/transparent</item>
        <item name="android:windowIsTranslucent">true</item>
        <item name="android:statusBarColor">@android:color/transparent</item>
        <item name="android:navigationBarColor">@android:color/transparent</item>
    </style>
</resources>
```

## 5. Performance checklist

- `key(item.id)` on every cell, never the index.
- Animated values read only inside lambda modifiers.
- Ship a Baseline Profile and enable R8 + resource shrinking; the biggest free win for launcher cold start.
- Avoid `Modifier.blur` on large areas; prefer window-level blur.
- Keep icon bitmaps small and cached; never decode on the main thread.
- Profile on a low-end device with the Compose compiler metrics report to catch unstable parameters.

## 6. Roadmap

1. Done: workspace grid, dock, pager, long-press drag with swap, spring press feedback
2. Widget hosting (`AppWidgetHost` inside `AndroidView`, spans from `AppWidgetProviderInfo`)
3. Gesture layer: swipe up (drawer), swipe down (control center, split left/right like HyperOS), pinch (home settings)
4. App drawer with search and category tabs
5. Control Center with window-level blur, toggles, sliders, media card
6. Room persistence, edge-drag to change pages mid-drag, folders, package install/uninstall receiver
