# HyperLauncher

Compose launcher inspired by HyperOS. Architecture notes: `ARCHITECTURE.md`.

## Run it

1. Install Android Studio (latest stable).
2. File > Open > choose this `HyperLauncher` folder. Wait for Gradle sync (needs internet the first time).
3. Plug in a phone (USB debugging on) or start an emulator, then press Run.
4. Press the Home button. Android asks which launcher to use: pick HyperLauncher, then "Always".

To go back to your old launcher: Settings > Apps > Default apps > Home app.

## Build an APK

- Android Studio: Build > Build Bundle(s) / APK(s) > Build APK(s)
- Or terminal: `./gradlew assembleDebug` (output: `app/build/outputs/apk/debug/app-debug.apk`)
