# Default rules are enough for this project.
