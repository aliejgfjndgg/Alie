package com.hyper.launcher.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.VectorConverter
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.PagerState
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.material3.Text
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.round
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.hyper.launcher.data.AppInfo
import com.hyper.launcher.data.GridItem
import com.hyper.launcher.data.LauncherViewModel
import kotlinx.coroutines.launch

// Shared spring specs: slightly under-damped so motion settles with a soft overshoot.
private val MoveSpring = spring<Offset>(dampingRatio = 0.78f, stiffness = 380f)
private val PressSpring = spring<Float>(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium)

@Composable
fun HomeScreen(vm: LauncherViewModel = viewModel()) {
    val items by vm.items.collectAsStateWithLifecycle()
    val dock by vm.dock.collectAsStateWithLifecycle()
    val pageCount by vm.pageCount.collectAsStateWithLifecycle()

    val pagerState = rememberPagerState { pageCount }
    var isDragging by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {
        HorizontalPager(
            state = pagerState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            beyondViewportPageCount = 1,
            userScrollEnabled = !isDragging,
            key = { it },
        ) { page ->
            val pageItems = remember(items, page) { items.filter { it.page == page } }
            WorkspacePage(
                items = pageItems,
                columns = vm.grid.columns,
                rows = vm.grid.rows,
                loadIcon = vm::icon,
                onLaunch = vm::launch,
                onMove = vm::moveItem,
                onDraggingChange = { isDragging = it },
            )
        }

        PageIndicator(pagerState, pageCount)

        Dock(
            apps = dock,
            loadIcon = vm::icon,
            onLaunch = vm::launch,
        )
    }
}

// ───────────────────────── Workspace ─────────────────────────

@Composable
private fun WorkspacePage(
    items: List<GridItem>,
    columns: Int,
    rows: Int,
    loadIcon: suspend (AppInfo) -> ImageBitmap?,
    onLaunch: (AppInfo) -> Unit,
    onMove: (id: String, page: Int, col: Int, row: Int) -> Unit,
    onDraggingChange: (Boolean) -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val density = LocalDensity.current
        val cellW = maxWidth / columns
        val cellH = maxHeight / rows
        val cellWpx = with(density) { cellW.toPx() }
        val cellHpx = with(density) { cellH.toPx() }

        items.forEach { item ->
            key(item.id) {
                DraggableAppCell(
                    item = item,
                    cellW = cellW,
                    cellH = cellH,
                    cellWpx = cellWpx,
                    cellHpx = cellHpx,
                    columns = columns,
                    rows = rows,
                    loadIcon = loadIcon,
                    onLaunch = onLaunch,
                    onMove = onMove,
                    onDraggingChange = onDraggingChange,
                )
            }
        }
    }
}

/**
 * One workspace icon.
 *
 * Position lives in an Animatable<Offset> read inside offset{} (layout phase), so a
 * moving icon never triggers recomposition. Scale is read inside graphicsLayer{} (draw phase).
 * The pointer modifiers sit *outside* graphicsLayer so drag deltas are not distorted by the
 * lift-scale, and *after* offset so the hit area follows the icon.
 */
@Composable
private fun DraggableAppCell(
    item: GridItem,
    cellW: Dp,
    cellH: Dp,
    cellWpx: Float,
    cellHpx: Float,
    columns: Int,
    rows: Int,
    loadIcon: suspend (AppInfo) -> ImageBitmap?,
    onLaunch: (AppInfo) -> Unit,
    onMove: (String, Int, Int, Int) -> Unit,
    onDraggingChange: (Boolean) -> Unit,
) {
    val scope = rememberCoroutineScope()
    val currentItem by rememberUpdatedState(item)
    val currentOnMove by rememberUpdatedState(onMove)

    val target = Offset(item.col * cellWpx, item.row * cellHpx)
    val pos = remember { Animatable(target, Offset.VectorConverter) }

    var dragging by remember { mutableStateOf(false) }
    var pressed by remember { mutableStateOf(false) }

    // Glide to the (possibly new) cell whenever the target changes or a drag ends.
    LaunchedEffect(target, dragging) {
        if (!dragging) pos.animateTo(target, MoveSpring)
    }

    val scale by animateFloatAsState(
        targetValue = when {
            dragging -> 1.12f
            pressed -> 0.92f
            else -> 1f
        },
        animationSpec = PressSpring,
        label = "cellScale",
    )

    val icon by produceState<ImageBitmap?>(null, item.app.id) { value = loadIcon(item.app) }

    Box(
        Modifier
            .offset { pos.value.round() }
            .size(cellW, cellH)
            .zIndex(if (dragging) 1f else 0f)
            .pointerInput(item.id) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onTap = { onLaunch(currentItem.app) },
                )
            }
            .pointerInput(item.id) {
                var raw = Offset.Zero
                detectDragGesturesAfterLongPress(
                    onDragStart = {
                        raw = pos.value
                        dragging = true
                        onDraggingChange(true)
                    },
                    onDrag = { change, delta ->
                        change.consume()
                        raw += delta
                        scope.launch { pos.snapTo(raw) }
                    },
                    onDragEnd = {
                        val center = pos.value + Offset(cellWpx / 2f, cellHpx / 2f)
                        val col = (center.x / cellWpx).toInt().coerceIn(0, columns - 1)
                        val row = (center.y / cellHpx).toInt().coerceIn(0, rows - 1)
                        currentOnMove(currentItem.id, currentItem.page, col, row)
                        dragging = false
                        onDraggingChange(false)
                    },
                    onDragCancel = {
                        dragging = false
                        onDraggingChange(false)
                    },
                )
            }
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                alpha = if (dragging) 0.92f else 1f
            },
        contentAlignment = Alignment.Center,
    ) {
        AppIconContent(icon = icon, label = item.app.label)
    }
}

// ───────────────────────── Shared visuals ─────────────────────────

@Composable
private fun AppIconContent(icon: ImageBitmap?, label: String, showLabel: Boolean = true) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(56.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.10f))
        ) {
            icon?.let {
                Image(
                    bitmap = it,
                    contentDescription = label,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        if (showLabel) {
            Spacer(Modifier.height(4.dp))
            Text(
                text = label,
                color = Color.White,
                fontSize = 11.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
                style = TextStyle(
                    shadow = Shadow(Color.Black.copy(alpha = 0.45f), blurRadius = 6f)
                ),
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
    }
}

@Composable
private fun PageIndicator(pagerState: PagerState, pageCount: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally),
    ) {
        repeat(pageCount) { index ->
            val selected = pagerState.currentPage == index
            val width by animateDpAsState(
                targetValue = if (selected) 18.dp else 6.dp,
                animationSpec = spring(dampingRatio = 0.7f, stiffness = 500f),
                label = "dotWidth",
            )
            Box(
                Modifier
                    .height(6.dp)
                    .width(width)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = if (selected) 0.95f else 0.45f))
            )
        }
    }
}

// ───────────────────────── Dock ─────────────────────────

@Composable
private fun Dock(
    apps: List<AppInfo>,
    loadIcon: suspend (AppInfo) -> ImageBitmap?,
    onLaunch: (AppInfo) -> Unit,
) {
    // Fake glass: translucent vertical gradient + thin highlight border.
    // Swap for window-level blur on API 31+ (see ARCHITECTURE.md).
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    listOf(Color.White.copy(alpha = 0.26f), Color.White.copy(alpha = 0.12f))
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.28f), shape)
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
    ) {
        apps.forEach { app ->
            key(app.id) {
                val icon by produceState<ImageBitmap?>(null, app.id) { value = loadIcon(app) }
                var pressed by remember { mutableStateOf(false) }
                val scale by animateFloatAsState(
                    targetValue = if (pressed) 0.88f else 1f,
                    animationSpec = PressSpring,
                    label = "dockScale",
                )
                Box(
                    Modifier
                        .pointerInput(app.id) {
                            detectTapGestures(
                                onPress = {
                                    pressed = true
                                    tryAwaitRelease()
                                    pressed = false
                                },
                                onTap = { onLaunch(app) },
                            )
                        }
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        }
                ) {
                    AppIconContent(icon = icon, label = app.label, showLabel = false)
                }
            }
        }
    }
}
