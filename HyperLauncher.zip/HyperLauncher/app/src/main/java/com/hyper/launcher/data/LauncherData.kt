package com.hyper.launcher.data

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.util.LruCache
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ───────────────────────── Models ─────────────────────────

@Immutable
data class AppInfo(
    val packageName: String,
    val activityName: String,
    val label: String,
) {
    val id: String get() = "$packageName/$activityName"
}

/** One occupied cell on the workspace. Spans are reserved for widgets later. */
@Immutable
data class GridItem(
    val id: String,
    val app: AppInfo,
    val page: Int,
    val col: Int,
    val row: Int,
    val spanX: Int = 1,
    val spanY: Int = 1,
)

@Immutable
data class GridConfig(
    val columns: Int = 4,
    val rows: Int = 6,
    val dockSize: Int = 4,
)

// ───────────────────────── Repository ─────────────────────────

class AppRepository(private val app: Application) {

    private val pm = app.packageManager

    // ~96 icons * 144x144x4 bytes ≈ 8 MB worst case. Small and bounded.
    private val iconCache = LruCache<String, ImageBitmap>(96)

    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        pm.queryIntentActivities(intent, 0)
            .asSequence()
            .filter { it.activityInfo.packageName != app.packageName }
            .map {
                AppInfo(
                    packageName = it.activityInfo.packageName,
                    activityName = it.activityInfo.name,
                    label = it.loadLabel(pm).toString(),
                )
            }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    suspend fun icon(info: AppInfo): ImageBitmap? {
        iconCache.get(info.id)?.let { return it }
        return withContext(Dispatchers.IO) {
            runCatching {
                pm.getActivityIcon(ComponentName(info.packageName, info.activityName))
                    .toBitmap(ICON_PX, ICON_PX)
                    .asImageBitmap()
            }.getOrNull()?.also { iconCache.put(info.id, it) }
        }
    }

    fun launch(info: AppInfo) {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
            component = ComponentName(info.packageName, info.activityName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
        }
        runCatching { app.startActivity(intent) }
    }

    private companion object {
        const val ICON_PX = 144
    }
}

// ───────────────────────── ViewModel ─────────────────────────

class LauncherViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = AppRepository(application)

    val grid = GridConfig()

    private val _items = MutableStateFlow<List<GridItem>>(emptyList())
    val items: StateFlow<List<GridItem>> = _items.asStateFlow()

    private val _dock = MutableStateFlow<List<AppInfo>>(emptyList())
    val dock: StateFlow<List<AppInfo>> = _dock.asStateFlow()

    val pageCount: StateFlow<Int> = _items
        .map { list -> (list.maxOfOrNull { it.page } ?: 0) + 1 }
        .stateIn(viewModelScope, SharingStarted.Eagerly, 1)

    init {
        viewModelScope.launch { seed(repo.loadApps()) }
    }

    /** First run layout: fill pages left-to-right, top-to-bottom. Replace with Room later. */
    private fun seed(apps: List<AppInfo>) {
        val dockApps = apps.take(grid.dockSize)
        val rest = apps.drop(grid.dockSize)
        val perPage = grid.columns * grid.rows
        _dock.value = dockApps
        _items.value = rest.mapIndexed { i, app ->
            val slot = i % perPage
            GridItem(
                id = app.id,
                app = app,
                page = i / perPage,
                col = slot % grid.columns,
                row = slot / grid.columns,
            )
        }
    }

    /** Moves an item to a cell; if the cell is taken, the two items swap. */
    fun moveItem(id: String, page: Int, col: Int, row: Int) {
        _items.update { list ->
            val moving = list.firstOrNull { it.id == id } ?: return@update list
            val occupant = list.firstOrNull {
                it.id != id && it.page == page && it.col == col && it.row == row
            }
            list.map {
                when (it.id) {
                    id -> it.copy(page = page, col = col, row = row)
                    occupant?.id -> it.copy(page = moving.page, col = moving.col, row = moving.row)
                    else -> it
                }
            }
        }
    }

    suspend fun icon(app: AppInfo): ImageBitmap? = repo.icon(app)

    fun launch(app: AppInfo) = repo.launch(app)
}
